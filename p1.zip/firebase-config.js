// Replace this with your actual Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyCB9w7bkg53wU30uEH71PoAgQZHY-eZtbk",
  authDomain: "electra-prime.firebaseapp.com",
  projectId: "electra-prime",
  storageBucket: "electra-prime.firebasestorage.app",
  messagingSenderId: "398159720259",
  appId: "1:398159720259:web:aeb608912c4df8091a09f6",
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();